#ifndef __MyDMA_H
#define __MyDMA_H


void MyDMA_Init(uint32_t AddrA, uint32_t AddrB, uint16_t Size);
void MyDMA_Transfer(void);


#endif
