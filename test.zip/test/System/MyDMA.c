#include "stm32f10x.h"                  // Device header

uint16_t MyDMA_Size;;

void MyDMA_Init(uint32_t AddrA, uint32_t AddrB, uint16_t Size)
{
	MyDMA_Size = Size;
	
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
	
	DMA_InitTypeDef DMA_InitStructure;
	DMA_InitStructure.DMA_PeripheralBaseAddr = AddrA;//外设站点的起始地址
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;//外设站点的数据宽度
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Enable;//外设站点地址是否自增
	DMA_InitStructure.DMA_MemoryBaseAddr = AddrB;//存储器站点的起始地址
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;//存储器站点的数据宽度
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;//存储器站点地址是否自增
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;//传输方向,DST外设站点作为目的地，SRC外设站点作为源头
	DMA_InitStructure.DMA_BufferSize = Size;//缓存区大小，即传输计数器
	DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;//传输模式，是否使用自动重装,自动重装和软件触发不能同时使用
	DMA_InitStructure.DMA_M2M = DMA_M2M_Enable;//是否是存储器到存储器(软件触发)，即选择硬件触发还是软件触发
	DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;//优先级
	DMA_Init(DMA1_Channel1, &DMA_InitStructure);
	
	DMA_Cmd(DMA1_Channel1, DISABLE);//不让DMA初始化后直接开始转运
}

void MyDMA_Transfer(void)	//DMA转运开启函数
{
	DMA_Cmd(DMA1_Channel1, DISABLE);//给传输计数器赋值前必须先给DMA失能
	DMA_SetCurrDataCounter(DMA1_Channel1, MyDMA_Size);//给传输计数器赋值
	DMA_Cmd(DMA1_Channel1, ENABLE);//开始转运
	
	while (DMA_GetFlagStatus(DMA1_FLAG_TC1) == RESET);//等待转运完成,GL全局标志位,TC转运完成标志位,HT转运过半标志位,TE转运错误标志位
	DMA_ClearFlag(DMA1_FLAG_TC1);
}
