#ifndef __ATGM336H_H
#define __ATGM336H_H

void errorLog(int num);
void parseGpsBuffer(void);
void printGpsBuffer(void);



#endif
