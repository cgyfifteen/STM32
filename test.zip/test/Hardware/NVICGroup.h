#ifndef __NVICGroup_H
#define __NVICGroup_H


void NVIC_Group(void);

#endif
