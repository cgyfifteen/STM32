#ifndef __LED_H
#define __LED_H


#define LED_IN_STA   GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_1) 

void LED_Init(void);
void LED_ON(void);
void LED_OFF(void);



#endif
