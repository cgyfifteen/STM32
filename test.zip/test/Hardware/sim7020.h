/*-------------------------------------------------*/
/*            ��γ����STM32ϵ�п�����              */
/*-------------------------------------------------*/
/*                                                 */
/*              ʵ��SIM7020���ܵ�ͷ�ļ�            */
/*                                                 */
/*-------------------------------------------------*/

#ifndef __SIM7020_H
#define __SIM7020_H


#define SIM7020_printf       u2_printf           //����2���� 7020ģ�� 
#define SIM7020_RxCounter    USART2_RxCounter    //����2���� 7020ģ��
#define SIM7020_RX_BUF       USART2_RxBuff       //����2���� 7020ģ��
#define SIM7020_RXBUFF_SIZE  USART2_RXBUFF_SIZE  //����2���� 7020ģ��

char SIM7020_ATTest_Cmd(int counter);
char SIM7020_CPIN_Cmd(int timeout);
char SIM7020_CGREG_Cmd(int timeout);
char SIM7020_CGACT_Cmd(int timeout);
char SIM7020_CSQ_Cmd(int timeout);
char SIM7020_CGCONTRDP_Cmd(int timeout);
char SIM7020_IPR_Cmd(int bound, int timeout);
char SIM7020_PSM_OFF(int timeout);
char SIM7020_eDRX_OFF(int timeout);
char SIM7020_Connect_IoTServer(void);
void SIM7020_Hex_to_Str(char *data, int data_len, char *out, int out_len);
void SIM7020_Str_to_Hex(char *data, int data_len, char *out, int out_len);
int SIM7020_StrNum_to_HexNum(char *data, int data_len);
char SIM7020_DNS(char * domainname, int timeout);
char SIM7020_TCPInit(int timeout);
char SIM7020_TCP_CSevver(int timeout);
char SIM7020_TCP_Send(int timeout,unsigned char *data, int data_len);
int SIM7020_TCP_Rev(unsigned char *redata,unsigned char *out,int out_len);
	
#endif
