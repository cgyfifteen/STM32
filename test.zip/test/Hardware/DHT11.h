#ifndef __DHT11_H
#define __DHT11_H
#include "stm32f10x.h"                  // Device header

#define DHT11_RCC RCC_APB2Periph_GPIOA
#define DHT11_PORT GPIOA
#define DHT11_IO GPIO_Pin_8
#define DHT11_LOW GPIO_ResetBits(DHT11_PORT,DHT11_IO)
#define DHT11_HIGH GPIO_SetBits(DHT11_PORT,DHT11_IO)

void DHT11_Config(void);
void DHT11_IO_OUT(void);
void DHT11_IO_IN(void);
void DHT11_Start(void);
void DHT11_Response(void);
u8 DHT11_Read_Bit(void);
u8 DHT11_Read_Byte(void);
void DHT11_Read_Data(u8 *temp, u8 *humi);



#endif
