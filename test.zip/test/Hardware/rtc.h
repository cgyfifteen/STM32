/*-------------------------------------------------*/
/*            ��γ����STM32ϵ�п�����              */
/*-------------------------------------------------*/
/*                                                 */
/*           ʵ��RTCʵʱʱ�ӹ��ܵ�ͷ�ļ�             */
/*                                                 */
/*-------------------------------------------------*/

#ifndef __RTC_H
#define __RTC_H	 

#include "stm32f10x.h"                  // Device header


extern RTC_TimeTypeDef RTC_TimeStruct;
extern RTC_DateTypeDef RTC_DateStruct;

ErrorStatus RTC_Set_Time(char hour,char min,char sec,char ampm);
ErrorStatus RTC_Set_Date(char year,char month,char date,char week);
char Rtc_Init(void);
void RTC_Set_AlarmA(char date,char hour,char min,char sec);
void RtcWakeUpConfig(int sec);

#endif

















