#include "stm32f10x.h"                  // Device header

void AD_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	RCC_ADCCLKConfig(RCC_PCLK2_Div6);	//ADC最大为14MHz，这里6分频为12MHz
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;	//模拟输入，ADC的专属模式
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	ADC_InitTypeDef ADC_InitStructure;
	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;	//配置ADC工作模式为独立模式
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;	//数据对齐为右对齐
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;	//外部触发源选择，此处为无外部触发源，即软件触发
	ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;	//连续转换模式 ENABLE or DISABLE
	ADC_InitStructure.ADC_ScanConvMode = DISABLE;	//扫描转换模式  ENABLE or DISABLE
	ADC_InitStructure.ADC_NbrOfChannel = 1;	//扫描模式所配置的通道数目 1~16
	ADC_Init(ADC1, &ADC_InitStructure);
	
	ADC_Cmd(ADC1, ENABLE);
	
	ADC_ResetCalibration(ADC1);	//复位校准,给复位校准状态值置1
	while (ADC_GetResetCalibrationStatus(ADC1));	//返回复位校准状态值，为0时说明复位校准完成
	ADC_StartCalibration(ADC1);	//启动校准
	while (ADC_GetCalibrationStatus(ADC1));	//获取校准状态，为0时校准完成
	
}

uint16_t AD_GetValue(uint8_t ADC_Channel)
{
	ADC_RegularChannelConfig(ADC1, ADC_Channel, 1, ADC_SampleTime_55Cycles5);	
	//选择规则组的输入通道,ADC_SampleTime_55Cycles5(55.5)为采样周期，转换周期为固定的12.5
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);	//软件触发转换函数								
	while (ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);	//获取标志位状态函数
/*	ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC);	//规则组和注入组转换完成标志位，EOC为0时正在转换，为1时转换完成;ADC_DR寄存器读完后再给其置0
	ADC_GetFlagStatus(ADC1, ADC_FLAG_AWD);	//模拟看门狗标志位
	ADC_GetFlagStatus(ADC1, ADC_FLAG_JEOC);	//注入组转换完成标志位
	ADC_GetFlagStatus(ADC1, ADC_FLAG_JSTRT);//注入组开始转换标志位
	ADC_GetFlagStatus(ADC1, ADC_FLAG_STRT);	//规则组开始转换标志位
*/
	return ADC_GetConversionValue(ADC1);	//读取ADC_DR寄存器的值，读完后硬件自动清除标志位(即给EOC置0)
}
