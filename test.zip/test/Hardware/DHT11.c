#include "stm32f10x.h"                  // Device header
#include "DHT11.h"
#include "delay.h"

void DHT11_Config(void)
{
	RCC_APB2PeriphClockCmd(DHT11_RCC,ENABLE);	//开始DHT11的时钟
}

void DHT11_IO_OUT (void)
{ //温湿度模块输出函数
	
	GPIO_InitTypeDef  GPIO_InitStructure; 	
    GPIO_InitStructure.GPIO_Pin = DHT11_IO; //选择端口号（0~15或all）                        
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //推挽输出       
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; //设置IO接口速度（2/10/50MHz）    
	GPIO_Init(DHT11_PORT, &GPIO_InitStructure);
}

void DHT11_IO_IN (void)
{ //温湿度模块输入函数
	GPIO_InitTypeDef  GPIO_InitStructure; 	
    GPIO_InitStructure.GPIO_Pin = DHT11_IO; //选择端口号（0~15或all）                        
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //上拉输入      
	GPIO_Init(DHT11_PORT, &GPIO_InitStructure);
}

void DHT11_Start (void)
{ 						//DHT11端口复位，发出起始信号（IO发送）
	DHT11_IO_OUT();							//端口为输出
	DHT11_LOW; 	//使总线为低电平
	Delay_Ms(18); 							//拉低至少18ms						
	DHT11_HIGH; 		//使总线为高电平							
	Delay_Us(40); 							//主机拉高20~40us
}

void DHT11_Response(void)
{ 		   //DHT11响应
    u8 retry = 0;			//定义临时变量
    DHT11_IO_IN();		//IO到输入状态	 
//GPIO端口输入时，配置为上拉输入或者浮空输入，因为外接上拉电阻，所以默认为高电平
//如果DHT11的数据线输入为低电平，且 retry 小于100，则将 retry 加1，并延时1微秒，重复这个过程直到 retry 大于等于100 或者DHT11的数据线输入变成低电平。如果 retry 大于等于100，表示检测失败，返回1；否则，将 retry 重置为0。
	while ((GPIO_ReadInputDataBit(DHT11_PORT,DHT11_IO) == 0) && (retry < 100))	//DHT11会拉低40~80us
	{
		retry++;
        Delay_Us(1);
    }
	retry = 0;
//如果DHT11的数据线输入为高电平，且 retry 小于100，则将 retry 加1，并延时1微秒，重复这个过程直到 retry 大于等于100 或者DHT11的数据线输入变成高电平。如果 retry 大于等于100，表示检测失败，返回1；否则，返回0，表示检测成功。
    while ((GPIO_ReadInputDataBit(DHT11_PORT,DHT11_IO) == 1) && (retry < 100))  //DHT11拉低后会再次拉高40~80us
	{  
        retry++;
        Delay_Us(1);
    }
	retry = 0;
}

//从DHT11读取一个位
//返回值：1/0
u8 DHT11_Read_Bit(void)
{
	u8 bit = 0;
	DHT11_IO_IN();
    u8 retry = 0;
    while((GPIO_ReadInputDataBit(DHT11_PORT,DHT11_IO) == 0) && (retry < 100)) //每输入一个数据前DHT11拉低总线50us
    {
        retry++;
        Delay_Us(1);
    }
    retry = 0;

    Delay_Us(40);//等待40us
    if(GPIO_ReadInputDataBit(DHT11_PORT,DHT11_IO) == 1)       //用于判断高低电平，即数据1或0
    {
		bit = 1;
		while((GPIO_ReadInputDataBit(DHT11_PORT,DHT11_IO) == 1) && (retry < 100)) 
		{
			retry++;
			Delay_Us(1);
		}
		retry = 0;

	}    
    else bit = 0;

	return bit;
}

//从DHT11读取一个字节
//返回值：读到的数据
u8 DHT11_Read_Byte(void)
{
    u8 i, data;
    data = 0;
    for (i = 0; i < 8; i++)
    {
        data <<= 1;					//左移运算符,dat左移1位
        data |= DHT11_Read_Bit();	//"|"表示按位或等于
    }
    return data;
}

//u8 DHT11_Read_Byte(void)
//{
//	u8 data = 0;
//	u8 retry = 0;
//	u8 i;
//	for(i = 0; i < 8; i++)
//	{
//		DHT11_IO_IN();
//		
//		while((GPIO_ReadInputDataBit(DHT11_PORT,DHT11_IO) == 0) && (retry < 100)) //每输入一个数据前DHT11拉低总线50us
//        {
//			retry++;
//            Delay_Us(1);
//        }
//        retry = 0;

//		data <<= 1;		
//		Delay_Us(40);
//		
//		if(GPIO_ReadInputDataBit(DHT11_PORT,DHT11_IO) == 1)
//		{
//			data |= 0x01;
//			
//			while((GPIO_ReadInputDataBit(DHT11_PORT,DHT11_IO) == 1) && (retry < 100))
//			{
//				retry++;
//				Delay_Us(1);				
//			}
//			retry = 0;
//		}		
//	}
//	return data;
//}

//从DHT11读取一次数据
//temp:温度值(范围:0~50°)
//humi:湿度值(范围:20%~90%)
//返回值：0,正常;1,读取失败
void DHT11_Read_Data(u8 *temp, u8 *humi)
{
    u8 DATA[5]={0,0,0,0,0};
    u8 i;
    DHT11_Start();						//STM32向DHT11发出起始信号
	DHT11_Response();                   //DHT11响应

    for(i = 0; i < 5; i++) 			//读取40位数据
    {
        DATA[i] = DHT11_Read_Byte();	//读出数据
    }
	
    if((DATA[0] + DATA[1] + DATA[2] + DATA[3]) == DATA[4])	//数据校验
    {
        *humi = DATA[0];				//将湿度值放入指针humi
        *temp = DATA[2];				//将温度值放入指针temp
    }
    else
	{
		for(i = 0; i < 5; i++)
		{
			DATA[i] = 0;
		}
		
	}
	
}
